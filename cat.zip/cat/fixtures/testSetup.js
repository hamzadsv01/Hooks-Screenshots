import { test as base, expect } from '@playwright/test';
import BasePage from '../Pages/BasePage.js';
import { attachScreenshotAfterEach } from '../utilities/screenshot.js';

const APP_URL = 'https://adactinhotelapp.com/';

export const test = base.extend({

    pageSetup: [
        async ({ page }, use) => {

            const basePage = new BasePage(page);

            await basePage.navigate(APP_URL);

            await use();
        },
        { auto: true }
    ]

});

test.afterEach(async ({ page }, testInfo) => {

    await attachScreenshotAfterEach(page, testInfo);

});

export { expect };
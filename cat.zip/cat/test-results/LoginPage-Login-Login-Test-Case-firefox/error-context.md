# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: LoginPage.spec.js >> Login >> Login Test Case
- Location: tests\LoginPage.spec.js:31:9

# Error details

```
Error: browserContext.close: Test ended.
Browser logs:

<launching> C:\Users\fa24-bftp-0007\AppData\Local\ms-playwright\firefox-1538\firefox\firefox.exe -no-remote -headless -profile C:\Users\FA24-B~1\AppData\Local\Temp\playwright_firefoxdev_profile-kbsWRV -juggler-pipe -silent
<launched> pid=5880
[pid=5880][err] *** You are running in headless mode.
[pid=5880][err] JavaScript warning: resource://services-settings/Utils.sys.mjs, line 119: unreachable code after return statement
[pid=5880][out] 
[pid=5880][out] Juggler listening to the pipe
[pid=5880][out] Crash Annotation GraphicsCriticalError: |[0][GFX1-]: RenderCompositorSWGL failed mapping default framebuffer, no dt (t=2.06827) [GFX1-]: RenderCompositorSWGL failed mapping default framebuffer, no dt
```
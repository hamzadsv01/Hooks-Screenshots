# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: AddToCart.spec.js >> Login, Add Products and Logout
- Location: tests\AddToCart.spec.js:7:5

# Error details

```
ReferenceError: Logout is not defined
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e6]:
        - generic [ref=e7]:
          - button "Open Menu" [ref=e8] [cursor=pointer]
          - img "Open Menu" [ref=e9]
        - generic [ref=e10]: Swag Labs
        - generic [ref=e12]: "1"
      - generic [ref=e15]: Your Cart
    - generic [ref=e18]:
      - generic [ref=e19]:
        - generic [ref=e20]: QTY
        - generic [ref=e21]: Description
        - generic [ref=e22]:
          - generic [ref=e23]: "1"
          - generic [ref=e24]:
            - link "Sauce Labs Backpack" [ref=e25] [cursor=pointer]:
              - /url: "#"
            - generic [ref=e27]: carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.
            - generic [ref=e28]:
              - generic [ref=e29]: $29.99
              - button "Remove" [ref=e30] [cursor=pointer]
      - generic [ref=e31]:
        - button [ref=e32] [cursor=pointer]:
          - img "Go back" [ref=e33]
          - text: Continue Shopping
        - button "Checkout" [ref=e34] [cursor=pointer]
  - contentinfo [ref=e35]:
    - list [ref=e36]:
      - listitem [ref=e37]:
        - link "Twitter" [ref=e38] [cursor=pointer]:
          - /url: https://twitter.com/saucelabs
      - listitem [ref=e39]:
        - link "Facebook" [ref=e40] [cursor=pointer]:
          - /url: https://www.facebook.com/saucelabs
      - listitem [ref=e41]:
        - link "LinkedIn" [ref=e42] [cursor=pointer]:
          - /url: https://www.linkedin.com/company/sauce-labs/
    - generic [ref=e43]: © 2026 Sauce Labs. All Rights Reserved. Terms of Service | Privacy Policy
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { LoginPage } from '../Pages/LoginPage.js';
  3  | import { AddToCart } from '../Pages/AddToCart.js';
  4  | 
  5  | import productsData from '../testdata/productsData.json' with { type: 'json' };
  6  | 
  7  | test('Login, Add Products and Logout', async ({ page }) => {
  8  | 
  9  |     // Get product indexes from terminal command
  10 |     const input = process.env.PRODUCTS || '0';
  11 | 
  12 |     const selectedIndexes = input
  13 |         .split(',')
  14 |         .map(index => Number(index.trim()));
  15 | 
  16 |     // Display selected products
  17 |     console.log('\nProducts selected:');
  18 | 
  19 |     selectedIndexes.forEach(index => {
  20 |         console.log(`- ${productsData.products[index].productName}`);
  21 |     });
  22 | 
  23 |     // Open website
  24 |     await page.goto('https://www.saucedemo.com/');
  25 | 
  26 |     // Login
  27 |     const loginPage = new LoginPage(page);
  28 |     await loginPage.login('standard_user', 'secret_sauce');
  29 | 
  30 |     // Add products
  31 |     const addToCart = new AddToCart(page);
  32 | 
  33 |     for (const index of selectedIndexes) {
  34 | 
  35 |         const product = productsData.products[index];
  36 | 
  37 |         await addToCart.addProduct(product.productId);
  38 |     }
  39 | 
  40 |     // Open cart
  41 |     await addToCart.openCart();
  42 | 
  43 |     // Logout
> 44 |     const logout = new Logout(page);
     |                    ^ ReferenceError: Logout is not defined
  45 |     await logout.logout();
  46 | 
  47 |     // Verify logout
  48 |     await expect(page).toHaveURL('https://www.saucedemo.com/');
  49 | });
```
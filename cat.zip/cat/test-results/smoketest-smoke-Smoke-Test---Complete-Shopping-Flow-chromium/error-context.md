# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoketest\smoke.spec.js >> Smoke Test - Complete Shopping Flow
- Location: tests\smoketest\smoke.spec.js:13:5

# Error details

```
Error: expect(page).toHaveText(expected) failed

Timeout: 5000ms
- Expected  - 1
+ Received  + 8

- Products
+
+
+   
+   Open MenuAll ItemsAboutLogoutReset App StateClose MenuSwag LabsProductsName (A to Z)Name (A to Z)Name (Z to A)Price (low to high)Price (high to low)Sauce Labs Backpackcarry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.$29.99Add to cartSauce Labs Bike LightA red light isn't the desired state in testing but it sure helps when riding your bike at night. Water-resistant with 3 lighting modes, 1 AAA battery included.$9.99Add to cartSauce Labs Bolt T-ShirtGet your testing superhero on with the Sauce Labs bolt T-shirt. From American Apparel, 100% ringspun combed cotton, heather gray with red bolt.$15.99Add to cartSauce Labs Fleece JacketIt's not every day that you come across a midweight quarter-zip fleece jacket capable of handling everything from a relaxing day outdoors to a busy day at the office.$49.99Add to cartSauce Labs OnesieRib snap infant onesie for the junior automation engineer in development. Reinforced 3-snap bottom closure, two-needle hemmed sleeved and bottom won't unravel.$7.99Add to cartTest.allTheThings() T-Shirt (Red)This classic Sauce Labs t-shirt is perfect to wear when cozying up to your keyboard to automate a few tests. Super-soft and comfy ringspun combed cotton.$15.99Add to cartTwitterFacebookLinkedIn© 2026 Sauce Labs. All Rights Reserved. Terms of Service | Privacy Policy
+
+
+
+

Call log:
  - Expect "toHaveText" with timeout 5000ms
    13 × locator resolved to <html lang="en">…</html>
       - unexpected value "

  
  Open MenuAll ItemsAboutLogoutReset App StateClose MenuSwag LabsProductsName (A to Z)Name (A to Z)Name (Z to A)Price (low to high)Price (high to low)Sauce Labs Backpackcarry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.$29.99Add to cartSauce Labs Bike LightA red light isn't the desired state in testing but it sure helps when riding your bike at night. Water-resistant with 3 lighting modes, 1 AAA battery included.$9.99Add to cartSauce Labs Bolt T-ShirtGet your testing superhero on with the Sauce Labs bolt T-shirt. From American Apparel, 100% ringspun combed cotton, heather gray with red bolt.$15.99Add to cartSauce Labs Fleece JacketIt's not every day that you come across a midweight quarter-zip fleece jacket capable of handling everything from a relaxing day outdoors to a busy day at the office.$49.99Add to cartSauce Labs OnesieRib snap infant onesie for the junior automation engineer in development. Reinforced 3-snap bottom closure, two-needle hemmed sleeved and bottom won't unravel.$7.99Add to cartTest.allTheThings() T-Shirt (Red)This classic Sauce Labs t-shirt is perfect to wear when cozying up to your keyboard to automate a few tests. Super-soft and comfy ringspun combed cotton.$15.99Add to cartTwitterFacebookLinkedIn© 2026 Sauce Labs. All Rights Reserved. Terms of Service | Privacy Policy



"

```

```yaml
- document:
  - button "Open Menu"
  - img "Open Menu"
  - text: Swag Labs Products Name (A to Z)
  - combobox:
    - option "Name (A to Z)" [selected]
    - option "Name (Z to A)"
    - option "Price (low to high)"
    - option "Price (high to low)"
  - link "Sauce Labs Backpack":
    - /url: "#"
    - img "Sauce Labs Backpack"
  - link "Sauce Labs Backpack":
    - /url: "#"
  - text: carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection. $29.99
  - button "Add to cart"
  - link "Sauce Labs Bike Light":
    - /url: "#"
    - img "Sauce Labs Bike Light"
  - link "Sauce Labs Bike Light":
    - /url: "#"
  - text: A red light isn't the desired state in testing but it sure helps when riding your bike at night. Water-resistant with 3 lighting modes, 1 AAA battery included. $9.99
  - button "Add to cart"
  - link "Sauce Labs Bolt T-Shirt":
    - /url: "#"
    - img "Sauce Labs Bolt T-Shirt"
  - link "Sauce Labs Bolt T-Shirt":
    - /url: "#"
  - text: Get your testing superhero on with the Sauce Labs bolt T-shirt. From American Apparel, 100% ringspun combed cotton, heather gray with red bolt. $15.99
  - button "Add to cart"
  - link "Sauce Labs Fleece Jacket":
    - /url: "#"
    - img "Sauce Labs Fleece Jacket"
  - link "Sauce Labs Fleece Jacket":
    - /url: "#"
  - text: It's not every day that you come across a midweight quarter-zip fleece jacket capable of handling everything from a relaxing day outdoors to a busy day at the office. $49.99
  - button "Add to cart"
  - link "Sauce Labs Onesie":
    - /url: "#"
    - img "Sauce Labs Onesie"
  - link "Sauce Labs Onesie":
    - /url: "#"
  - text: Rib snap infant onesie for the junior automation engineer in development. Reinforced 3-snap bottom closure, two-needle hemmed sleeved and bottom won't unravel. $7.99
  - button "Add to cart"
  - link "Test.allTheThings() T-Shirt (Red)":
    - /url: "#"
    - img "Test.allTheThings() T-Shirt (Red)"
  - link "Test.allTheThings() T-Shirt (Red)":
    - /url: "#"
  - text: This classic Sauce Labs t-shirt is perfect to wear when cozying up to your keyboard to automate a few tests. Super-soft and comfy ringspun combed cotton. $15.99
  - button "Add to cart"
  - contentinfo:
    - list:
      - listitem:
        - link "Twitter":
          - /url: https://twitter.com/saucelabs
      - listitem:
        - link "Facebook":
          - /url: https://www.facebook.com/saucelabs
      - listitem:
        - link "LinkedIn":
          - /url: https://www.linkedin.com/company/sauce-labs/
    - text: © 2026 Sauce Labs. All Rights Reserved. Terms of Service | Privacy Policy
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | import { LoginPage } from '../../Pages/LoginPage.js';
  4  | import { AddToCart } from '../../Pages/AddToCart.js';
  5  | import { Checkout } from '../../Pages/Checkout.js';
  6  | 
  7  | 
  8  | import loginData from '../../testdata/loginData.json' with { type: 'json' };
  9  | import productsData from '../../testdata/productsData.json' with { type: 'json' };
  10 | import checkoutData from '../../testdata/checkoutData.json' with { type: 'json' };
  11 | 
  12 | 
  13 | test('Smoke Test - Complete Shopping Flow', async ({ page }) => {
  14 | 
  15 |     // 1. Open SauceDemo
  16 |     await page.goto('https://www.saucedemo.com/');
  17 | 
  18 | 
  19 |     // 2. Login
  20 |     const loginPage = new LoginPage(page);
  21 | 
  22 |     await loginPage.login(
  23 |         loginData.validUsers[0].username,
  24 |         loginData.validUsers[0].password
  25 |     );
  26 | 
  27 | 
  28 |     // 3. Verify Products Page
  29 |     await expect(
  30 |         page.locator(loginPage.ProductLabel)
> 31 |     ).toHaveText('Products');
     |       ^ Error: expect(page).toHaveText(expected) failed
  32 | 
  33 | 
  34 |     // 4. Add Product
  35 |     const addToCart = new AddToCart(page);
  36 | 
  37 |     await addToCart.addProduct(
  38 |         productsData.products[0].productId
  39 |     );
  40 | 
  41 | 
  42 |     // 5. Open Cart
  43 |     await page.locator('#shopping_cart_container a').click();
  44 | 
  45 | 
  46 |     // Verify Cart Page
  47 |     await expect(
  48 |         page.locator('.title')
  49 |     ).toHaveText('Your Cart');
  50 | 
  51 | 
  52 |     // 6. Checkout
  53 |     const checkout = new Checkout(page);
  54 | 
  55 |     await checkout.checkout(
  56 |         checkoutData.checkout[0].firstName,
  57 |         checkoutData.checkout[0].lastName,
  58 |         checkoutData.checkout[0].postalCode
  59 |     );
  60 | 
  61 | 
  62 |     // 7. Verify Order Completed
  63 |     await expect(
  64 |         page.locator('.complete-header')
  65 |     ).toHaveText('Thank you for your order!');
  66 | 
  67 | 
  68 |     // 8. Logout
  69 |     const logoutPage = new LogoutPage(page);
  70 | 
  71 |     await logoutPage.logout();
  72 | 
  73 | 
  74 |     // 9. Verify Login Page
  75 |     await expect(
  76 |         page.locator('#login-button')
  77 |     ).toBeVisible();
  78 | 
  79 | });
```